package com.route.islami_app_c38.UI

object Constant {

    const val EXTRA_CHAPTER_INDEX = "Index"
    const val EXTRA_CHAPTER_NAME = "name"
    const val EXTRA_HADETH = "hadeth"
    const val SOBHANALLAH = "سبحان الله"
    const val ALHAMDALLAH = "الحمد الله"
    const val ALLAH_AKBAR = "الله اكبر"
    const val LA_ALAH_EL_ALLAH = "لا اله الا الله"

}